import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import ipaddress
import socket

import joblib
import pandas as pd
import requests
import streamlit as st
from bs4 import BeautifulSoup
from PIL import Image

st.set_page_config(page_title="TruthSync AI", page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")
ROOT = Path(__file__).parent
st.markdown('''<style>
.stApp {background:radial-gradient(circle at 85% 0%,#262052 0%,#090d1b 42%);color:#f4f7ff}
.block-container {padding-top:2rem;max-width:1300px}
.hero {padding:36px;border-radius:25px;background:linear-gradient(110deg,#312e81,#6d28d9 55%,#0891b2);box-shadow:0 15px 45px #0005;margin-bottom:25px}
.hero h1 {font-size:3rem;margin:0;color:white}.hero p{color:#e0e7ff;font-size:1.1rem}
.tile {padding:22px;border:1px solid #3c4261;background:#151b30;border-radius:20px;min-height:120px;margin:8px 0}
.tile h3{margin:0 0 8px;color:#c4b5fd}.tile p{color:#cbd5e1;margin:0}
div.stButton>button {background:linear-gradient(90deg,#7c3aed,#0891b2);color:white;border:0;border-radius:12px;padding:.6rem 1.3rem}
[data-testid="stSidebar"] {background:#101629}
</style>''', unsafe_allow_html=True)

if 'history' not in st.session_state: st.session_state.history=[]

def record(kind, summary, status):
    st.session_state.history.insert(0, {'Time':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),'Type':kind,'Input':summary[:100],'Status':status})
    import os
    api=str(st.secrets.get('TRUTHSYNC_API_URL', os.getenv('TRUTHSYNC_API_URL',''))).rstrip('/')
    key=str(st.secrets.get('TRUTHSYNC_APP_KEY', os.getenv('TRUTHSYNC_APP_KEY','')))
    if api and key:
        try:
            requests.post(api+'/api/results',json={'kind':kind,'headline':summary[:100],'verdict':status,'detail':summary[:500]},headers={'X-App-Key':key},timeout=4).raise_for_status()
        except requests.RequestException as exc:
            st.warning('Device sync unavailable: '+str(exc))


def load_model():
    model_path, vector_path = ROOT/'model'/'classifier.joblib', ROOT/'model'/'vectorizer.joblib'
    if model_path.exists() and vector_path.exists():
        return joblib.load(model_path), joblib.load(vector_path)
    return None, None

def analyze_text(text):
    if len(text.strip()) < 30:
        st.warning('Enter at least 30 characters for analysis.');return
    model, vectorizer = load_model()
    if model is None:
        st.info('Prediction model not installed. Add model/classifier.joblib and model/vectorizer.joblib to enable ML predictions. No fake verdict has been generated.')
        record('Text',text,'Awaiting model');return
    try:
        X=vectorizer.transform([text]); prediction=model.predict(X)[0]
        st.subheader('Model prediction')
        st.metric('Predicted class',str(prediction))
        if hasattr(model,'predict_proba'):
            probs=model.predict_proba(X)[0]
            st.write('Model class probabilities (not fact-checking certainty):')
            st.bar_chart(pd.DataFrame({'Class':list(map(str,model.classes_)),'Probability':probs}).set_index('Class'))
        st.caption('This is a statistical model prediction, not proof that a claim is true or false. Confirm with primary sources.')
        record('Text',text,str(prediction))
    except Exception as e: st.error(f'Model inference failed: {e}')

def safe_article(url):
    parsed=urlparse(url)
    if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password: raise ValueError('Enter a public HTTP(S) article URL.')
    host=parsed.hostname.lower()
    if host=='localhost' or host.endswith(('.localhost','.local','.internal')): raise ValueError('Local/private hosts are blocked.')
    # Resolve and block private network targets; redirects are disabled.
    addresses=socket.getaddrinfo(host,None,type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses): raise ValueError('Non-public network addresses are blocked.')
    # For production deployment, enforce outbound firewall/DNS pinning too.
    r=requests.get(url,timeout=8,headers={'User-Agent':'TruthSyncAI/1.0'},allow_redirects=False,stream=True)
    if 300<=r.status_code<400: raise ValueError('Redirected URLs are not followed for safety; provide the final article URL.')
    r.raise_for_status()
    if 'text/html' not in r.headers.get('Content-Type','').lower(): raise ValueError('URL is not an HTML article.')
    raw=r.raw.read(1_000_001,decode_content=True)
    if len(raw)>1_000_000: raise ValueError('Article exceeds 1 MB limit.')
    soup=BeautifulSoup(raw,'html.parser')
    for el in soup(['script','style','nav','footer','header']):el.decompose()
    title=soup.title.get_text(' ',strip=True) if soup.title else 'Untitled article'
    article=soup.find('article') or soup
    body=' '.join(p.get_text(' ',strip=True) for p in article.find_all('p'))
    return title,body[:15000]

with st.sidebar:
    st.markdown('## 🛡️ TruthSync AI')
    st.caption('Intelligent misinformation analysis')
    page=st.radio('Navigation',['Dashboard','Text Analysis','Image Verification','Video Analysis','URL Fact Check','AI Image Generation','History','Connected OLED Device','Hardware API'],label_visibility='collapsed')
    st.divider();st.caption('Prototype • Verification requires trusted evidence')

if page=='Dashboard':
    st.markdown('<div class="hero"><h1>Verify Before You Trust.</h1><p>One workspace for news, images, videos and online claims.</p></div>',unsafe_allow_html=True)
    cols=st.columns(4)
    for c,(title,description) in zip(cols,[('📰 Text','ML-assisted article classification'),('🖼️ Image','Inspect uploaded media'),('🎬 Video','Inspect video metadata'),('🔗 URL','Extract and analyze news articles')]):
        with c:st.markdown(f'<div class="tile"><h3>{title}</h3><p>{description}</p></div>',unsafe_allow_html=True)
    st.subheader('Your session');st.metric('Analyses this session',len(st.session_state.history))
    st.info('Select a module from the sidebar to begin. Uploads and analysis history are session-only in this starter app.')
elif page=='Connected OLED Device':
    st.title('📟 Connected OLED Device')
    st.caption('The device polls the same latest result shown in the app. OLED displays a concise 128×64 version of the shared result, not the entire webpage.')
    api=st.text_input('Backend base URL',value=st.session_state.get('api_url','http://localhost:8000'))
    st.session_state.api_url=api
    st.code('GET /api/device/latest   |   X-Device-Key: <your key>')
    st.info('Start the backend, set TRUTHSYNC_API_URL and TRUTHSYNC_APP_KEY, then analyze text. ESP32 firmware polls the backend using its own device key.')
    if st.button('Check backend'):
        try:
            r=requests.get(api.rstrip('/')+'/health',timeout=5)
            st.json(r.json())
        except Exception as e: st.error(str(e))
elif page=='Text Analysis':
    st.title('📰 Text Analysis');text=st.text_area('Paste a news headline, claim or article',height=220,placeholder='Paste news content here...')
    if st.button('Analyze text',type='primary'):analyze_text(text)
elif page=='Image Verification':
    st.title('🖼️ Image Verification');up=st.file_uploader('Upload JPG, PNG or WEBP',type=['jpg','jpeg','png','webp'])
    if up:
        try:
            im=Image.open(up);im.verify();up.seek(0);im=Image.open(up)
            st.image(im,caption='Uploaded image',use_container_width=True)
            st.write({'Format':im.format,'Dimensions':f'{im.width} × {im.height}','Mode':im.mode,'Size (bytes)':up.size})
            st.warning('Image authenticity and manipulation detection require a separate forensic or reverse-image-search service. Metadata alone cannot establish truth.')
            if st.button('Save inspection to history'):record('Image',up.name,'Metadata inspected');st.success('Added to session history')
        except Exception:st.error('Could not read this image.')
elif page=='Video Analysis':
    st.title('🎬 Video Analysis');up=st.file_uploader('Upload MP4, MOV or WEBM (up to 200 MB)',type=['mp4','mov','webm'])
    if up:
        st.video(up);st.write({'Filename':up.name,'Size (MB)':round(up.size/1048576,2),'MIME type':up.type})
        st.warning('Video playback and file metadata are available. Deepfake, frame-level and audio analysis are not enabled until a validated backend is connected.')
        if st.button('Save inspection to history'):record('Video',up.name,'Metadata inspected');st.success('Added to session history')
elif page=='URL Fact Check':
    st.title('🔗 News URL Fact Check');url=st.text_input('Public article URL',placeholder='https://example.com/news/article')
    if st.button('Extract and analyze URL',type='primary'):
        try:
            title,body=safe_article(url);st.subheader(title)
            if body:
                with st.expander('Extracted article text',expanded=True):st.write(body)
                analyze_text(body)
            else:st.warning('No article paragraphs were extracted. Try pasting the article in Text Analysis.')
        except Exception as e:st.error(f'Unable to fetch article: {e}')
elif page=='AI Image Generation':
    st.title('✨ AI Image Generation');st.info('Integration-ready module. Connect an authorized image-generation API using Streamlit secrets. No image is generated in this starter version.')
    prompt=st.text_area('Describe an original illustration or educational visual')
    if prompt:st.code(prompt,language=None)
    st.caption('Clearly label generated images as synthetic. Never present them as documentary evidence.')
elif page=='History':
    st.title('📋 Session History')
    if st.session_state.history:
        df=pd.DataFrame(st.session_state.history);st.dataframe(df,use_container_width=True)
        st.download_button('Export CSV',df.to_csv(index=False),'truthsync_history.csv','text/csv')
        if st.button('Clear session history'):st.session_state.history=[];st.rerun()
    else:st.info('No analyses recorded yet.')
elif page=='Hardware API':
    st.title('📟 Hardware Integration');st.info('Connect your ESP32/Pico W using a separate authenticated backend. Do not embed device API keys in frontend code.')
    st.code(json.dumps({'device_id':'YOUR_DEVICE_ID','status':'awaiting_backend','last_analysis':{'label':'needs_review','confidence':None}},indent=2),language='json')
    st.caption('Recommended backend routes: GET /api/device/latest and POST /api/device/events with HTTPS and per-device credentials.')
