# TruthSync AI — deploy-ready starter

## Important: the ZIP itself is not uploaded into Streamlit Cloud
Extract this ZIP, upload its **contents** to a GitHub repository, then select `app.py` as the Streamlit main file.

## A. Deploy the frontend (Streamlit Community Cloud)
1. Extract the ZIP on your computer.
2. Create a GitHub repository and upload the files so `app.py` and `requirements.txt` appear in the repository root (not inside another nested folder).
3. On https://share.streamlit.io/ choose that repository, branch `main`, main file path `app.py`.
4. Click Deploy. The frontend can run without the optional trained model; text predictions will remain disabled until the model files are supplied.

## B. Deploy the backend (for ESP32 OLED synchronization)
1. Use the same GitHub repository at https://dashboard.render.com/ or create a Render Blueprint from `render.yaml`.
2. The backend service command is: `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`.
3. Set `TRUTHSYNC_APP_KEY` and `TRUTHSYNC_DEVICE_KEY` to distinct strong secrets. If using the Render Blueprint, review generated values in Render environment settings.
4. Copy the backend's HTTPS URL. In Streamlit app settings -> Secrets, add:

```toml
TRUTHSYNC_API_URL = "https://YOUR-BACKEND.onrender.com"
TRUTHSYNC_APP_KEY = "the-same-app-key-configured-on-backend"
```

5. In `firmware/TruthSync_ESP32_OLED.ino`, set Wi-Fi credentials, `API_URL` to `https://YOUR-BACKEND.onrender.com/api/device/latest`, and `DEVICE_KEY` to the backend's `TRUTHSYNC_DEVICE_KEY`.
6. Install Adafruit SSD1306, Adafruit GFX, and ArduinoJson in Arduino IDE. Firmware uses ESP32, SSD1306 OLED, SDA GPIO26 and SCL GPIO27.

## Limitations / safety
- This is a starter app; it does not include a trained news classifier, image generation API, image-forensics model, or video deepfake model. It explicitly avoids fabricating predictions.
- The OLED shows a compact version of the latest backend result (not every pixel or panel of the full webpage), because a 128x64 display cannot mirror a browser UI.
- SQLite on ephemeral cloud storage may lose data when a service restarts/redeploys. Use a managed PostgreSQL database or persistent disk for durable history.
- Do not commit API keys, Wi-Fi passwords, or `secrets.toml` to GitHub. For production, use HTTPS and TLS certificate validation on the device.
