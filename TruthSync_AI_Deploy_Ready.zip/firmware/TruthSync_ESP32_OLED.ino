
/*
 TruthSync AI ESP32 + SSD1306 128x64 OLED.
 SDA GPIO26, SCL GPIO27 (change to match your wiring).
 Install ArduinoJson, Adafruit GFX, Adafruit SSD1306.
 OLED shows the same latest RESULT data as the Streamlit app, condensed to fit.
 Backend must be reachable from ESP32; localhost will NOT work on the device.
*/
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ArduinoJson.h>
#define SDA_PIN 26
#define SCL_PIN 27
#define OLED_ADDR 0x3C
Adafruit_SSD1306 display(128,64,&Wire,-1);
const char* WIFI_SSID="YOUR_WIFI_SSID";
const char* WIFI_PASSWORD="YOUR_WIFI_PASSWORD";
const char* API_URL="http://192.168.1.100:8000/api/device/latest";
const char* DEVICE_KEY="REPLACE_WITH_TRUTHSYNC_DEVICE_KEY";
unsigned long lastPoll=0;
String clip(String s,int n){s.replace("\n"," ");return s.length()>n?s.substring(0,n):s;}
void screen(String line1,String line2,String line3,String line4,String line5){
 display.clearDisplay();display.setTextColor(SSD1306_WHITE);display.setTextSize(1);
 display.setCursor(0,0);display.println("TruthSync AI");
 display.drawLine(0,10,127,10,SSD1306_WHITE);
 display.setCursor(0,14);display.println(clip(line1,21));
 display.setCursor(0,24);display.println(clip(line2,21));
 display.setCursor(0,34);display.println(clip(line3,21));
 display.setCursor(0,44);display.println(clip(line4,21));
 display.setCursor(0,54);display.println(clip(line5,21));display.display();
}
void setup(){
 Serial.begin(115200);Wire.begin(SDA_PIN,SCL_PIN);
 if(!display.begin(SSD1306_SWITCHCAPVCC,OLED_ADDR)){Serial.println("OLED not found");while(true)delay(1000);}
 screen("Starting...","","","","");
 WiFi.mode(WIFI_STA);WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
 unsigned long started=millis();
 while(WiFi.status()!=WL_CONNECTED && millis()-started<20000){delay(400);}
 if(WiFi.status()==WL_CONNECTED)screen("WiFi connected",WiFi.localIP().toString(),"Waiting for result","","");
 else screen("WiFi offline","Check credentials","","","");
}
void loop(){
 if(millis()-lastPoll<5000)return;
 lastPoll=millis();
 if(WiFi.status()!=WL_CONNECTED){WiFi.reconnect();screen("WiFi disconnected","Reconnecting...","","","");return;}
 HTTPClient http;http.setTimeout(4000);
 if(!http.begin(API_URL)){screen("Invalid API URL","","","","");return;}
 http.addHeader("X-Device-Key",DEVICE_KEY);
 int status=http.GET();
 if(status==200){
  JsonDocument doc;
  DeserializationError error=deserializeJson(doc,http.getStream());
  if(error){screen("Invalid JSON","","","","");}
  else{
   String kind=doc["kind"]|String("SYSTEM");
   String verdict=doc["verdict"]|String("READY");
   String headline=doc["headline"]|String("");
   int id=doc["id"]|0;
   screen("TYPE: "+kind,"RESULT: "+verdict,clip(headline,21),
     headline.length()>21?clip(headline.substring(21),21):"",
     "SYNC ID: "+String(id));
   Serial.printf("Latest result %d: %s / %s\n",id,kind.c_str(),verdict.c_str());
  }
 }else{screen("Sync unavailable","HTTP "+String(status),"Check API / key","","");}
 http.end();
}
