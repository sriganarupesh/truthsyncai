
import os, sqlite3, secrets
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

DB=Path(os.getenv("TRUTHSYNC_DB","truthsync.sqlite3"))
APP_KEY=os.getenv("TRUTHSYNC_APP_KEY","")
DEVICE_KEY=os.getenv("TRUTHSYNC_DEVICE_KEY","")
app=FastAPI(title="TruthSync Device Sync API",version="1.0")

@contextmanager
def conn():
    c=sqlite3.connect(DB)
    try:
        yield c
        c.commit()
    finally: c.close()

with conn() as c:
    c.execute("""CREATE TABLE IF NOT EXISTS results
      (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
       kind TEXT NOT NULL, headline TEXT NOT NULL, verdict TEXT NOT NULL, detail TEXT NOT NULL)""")

class Result(BaseModel):
    kind:str=Field(min_length=1,max_length=30)
    headline:str=Field(min_length=1,max_length=200)
    verdict:str=Field(min_length=1,max_length=80)
    detail:str=Field(default="",max_length=1000)

def authorize(given,expected):
    if not expected or not given or not secrets.compare_digest(given,expected):
        raise HTTPException(status_code=401,detail="Invalid or unconfigured key")

@app.get("/health")
def health(): return {"status":"online","service":"TruthSync API"}

@app.post("/api/results")
def add_result(result:Result,x_app_key:str|None=Header(default=None)):
    authorize(x_app_key,APP_KEY)
    timestamp=datetime.now(timezone.utc).isoformat()
    with conn() as c:
        cur=c.execute("INSERT INTO results(created_at,kind,headline,verdict,detail) VALUES(?,?,?,?,?)",
            (timestamp,result.kind,result.headline,result.verdict,result.detail))
        id=cur.lastrowid
    return {"id":id,"created_at":timestamp,**result.model_dump()}

@app.get("/api/device/latest")
def latest(x_device_key:str|None=Header(default=None)):
    authorize(x_device_key,DEVICE_KEY)
    with conn() as c:
        c.row_factory=sqlite3.Row
        row=c.execute("SELECT * FROM results ORDER BY id DESC LIMIT 1").fetchone()
    if row is None:
        return {"id":0,"kind":"SYSTEM","headline":"Awaiting first analysis","verdict":"READY","detail":"","created_at":""}
    return dict(row)
